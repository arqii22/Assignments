console.log("page loaded...");

function over(element) {
    element.play();
    console.log("execute over");
}

function out(element){
    element.pause();
    console.log("execute out");
}
