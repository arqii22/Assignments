for (var x=1; x<20; x+=2){
    console.log(x);
}

for (var y=100; y >-1; y--){
    if (y % 3 == 0){
        console.log(y)
    }
}


for(var z=4; z>-4; z-=1.5){
    console.log(z);
}

var sum=0
for(var i=1; i<101; i++){
    sum +=i;
}
console.log(sum)

var product= 1;
for(var i=1; i<13; i++){
    product *=i;
}
console.log(product)